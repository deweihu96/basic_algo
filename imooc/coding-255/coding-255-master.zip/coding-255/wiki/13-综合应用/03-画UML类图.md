# 画 UML 类图

根据项目演示，分析功能，并画出 UML 类图。

![uml](./img/1.png)

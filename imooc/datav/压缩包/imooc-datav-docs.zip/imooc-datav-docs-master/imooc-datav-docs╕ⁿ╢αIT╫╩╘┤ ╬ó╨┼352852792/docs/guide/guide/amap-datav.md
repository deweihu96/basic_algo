# 高德地图可视化

## 绘制点

<iframe 
  src="https://www.youbaobao.xyz/datav-res/examples/test-amap.html"
  width="100%"
  height="400"
/>

::: details
```html
```
:::



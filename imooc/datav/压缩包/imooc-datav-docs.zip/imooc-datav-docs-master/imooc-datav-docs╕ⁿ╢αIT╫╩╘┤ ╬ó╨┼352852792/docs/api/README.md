---
sidebar: auto
---

# API

## 报表/大屏数据

`GET /screen/data`

## 报表地图散点数据

`GET /screen/map/scatter`

## 报表词云数据

`GET /screen/wordcloud`

## 数据大屏地图数据

`GET /screen/map`

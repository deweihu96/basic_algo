<template>
  <div class="separator" />
</template>

<script>
  export default {
    name: 'separator'
  }
</script>

<style lang="scss" scoped>
  .separator {
    width: 100%;
    height: 10px;
    background: rgb(92, 88, 89);
    filter: blur(0px);
    backdrop-filter: blur(0px);
  }
</style>
